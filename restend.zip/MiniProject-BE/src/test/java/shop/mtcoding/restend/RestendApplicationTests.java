package shop.mtcoding.restend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestendApplicationTests {

    @Test
    void contextLoads() {
    }

}
